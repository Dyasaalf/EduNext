<?php

namespace App\Controllers;

class Materi extends BaseController
{
    public function index()
    {
        // Pastikan user sudah login
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        // Ambil data materi dari model
        $model = new \App\Models\MateriModel();
        $data['materi'] = $model->findAll();

        return view('materi_view', $data); // Buat file view baru bernama materi_view.php
    }
}