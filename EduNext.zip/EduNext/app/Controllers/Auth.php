<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function login()
    {
        // Jika sudah login, langsung lempar ke dashboard, jangan kasih lihat form login lagi
        if (session()->get('logged_in')) {
            return redirect()->to(base_url('dashboard'));
        }
        return view('login');
    }

    public function processLogin()
    {
        $model = new UserModel();
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password') ?? ''; // Pastikan tidak null

        // Cari user berdasarkan email
        $user = $model->where('email', $email)->first();
        

        // REVISI: Logika pengecekan password ganda (Hash & Plain Text)
        $isPasswordValid = false;

        if ($user) {
            // Cek 1: Apakah password cocok dengan format Hash Bcrypt yang aman?
            if (password_verify($password, $user['password'])) {
                $isPasswordValid = true;
            } 
            // Cek 2: Apakah password cocok dengan Teks Biasa (Plain Text) di database?
            // Ini sangat berguna saat testing lokal jika input data manual dari phpMyAdmin
            elseif ($password === $user['password']) {
                $isPasswordValid = true;
            }
        }

        // Jika salah satu pengecekan di atas bernilai true (Valid)
        if ($isPasswordValid) {
            // SET SESSION (Kunci utama agar Dashboard bisa terbuka)
            session()->set([
                'id'        => $user['id'],
                'role'      => $user['role'],
                'nama'      => $user['nama'] ?? 'User', // Ambil nama jika ada
                'logged_in' => true // Nama kunci ini HARUS SAMA dengan di Dashboard.php
            ]);

            // Gunakan base_url() agar redirect di Docker tidak error
            return redirect()->to(base_url('dashboard'));
        } else {
            // Jika gagal, kembalikan ke login dengan pesan error
            return redirect()->back()->withInput()->with('error', 'Email atau Password salah!');
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to(base_url('login'));
    }

    /**
     * FITUR TAMBAHAN (Hanya untuk Bantuan Development):
     * Jika kamu butuh mengubah password 'admin123' menjadi Hash Bcrypt untuk di-copy ke phpMyAdmin,
     * cukup akses URL ini di browser: http://localhost/kursus_online/public/auth/generate
     */
    public function generate()
    {
        $password_mentah = 'admin123'; // Ganti teks ini jika ingin membuat hash untuk password lain
        $password_hash = password_hash($password_mentah, PASSWORD_DEFAULT);
        
        echo "<h3>Generate Password Hash Berhasil!</h3>";
        echo "<p>Password asli: <b>" . $password_mentah . "</b></p>";
        echo "<p>Copy teks tebal di bawah ini dan Paste ke kolom password di database (phpMyAdmin):</p>";
        echo "<p style='padding:10px; background:#f4f4f4; border:1px solid #ddd;'><b>" . $password_hash . "</b></p>";
    }
}