<?php

namespace App\Controllers;

use App\Models\MateriModel;

class Dashboard extends BaseController
{
    /**
     * Halaman Utama Dashboard
     */
    public function index()
    {
        // PROTEKSI: Cek apakah user sudah login
        if (!session()->get('logged_in')) {
            return redirect()->to(base_url('login'))->with('error', 'Silakan login terlebih dahulu.');
        }

        $model = new MateriModel();
        
        $data = [
            'materi' => $model->findAll(),
            'role'   => session()->get('role'), 
            'nama'   => session()->get('nama')  
        ];

        return view('dashboard', $data);
    }

    /**
     * KHUSUS ADMIN: Fungsi untuk mengupload materi baru
     */
    public function upload()
    {
        // 1. PROTEKSI BERLAPIS: Pastikan sudah login DAN rolenya admin
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'))->with('error', 'Anda tidak memiliki akses untuk fitur ini.');
        }

        // 2. VALIDASI KEAMANAN (Mencegah upload file sembarangan / kebesaran)
        // Sesuaikan max_size (dalam KB). 102400 KB = 100 MB.
        $rules = [
            'judul'       => 'required',
            'tipe_file'   => 'required',
            'file_materi' => 'uploaded[file_materi]|max_size[file_materi,102400]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->to(base_url('dashboard'))->with('error', 'Gagal upload! Pastikan form terisi dan ukuran file tidak melebihi batas.');
        }

        // 3. AMBIL DATA
        $file = $this->request->getFile('file_materi');
        $judul = $this->request->getPost('judul');
        $tipe  = $this->request->getPost('tipe_file');

        if ($file->isValid() && !$file->hasMoved()) {
            // Beri nama acak agar tidak bentrok jika ada nama file yang sama
            $newName = $file->getRandomName();
            
            // Pindah file ke public/uploads/
            $file->move(ROOTPATH . 'public/uploads', $newName);

            // SIMPAN KE DATABASE
            $model = new MateriModel();
            $model->save([
                'judul'     => $judul,
                'tipe_file' => $tipe, 
                'nama_file' => $newName
            ]);

            return redirect()->to(base_url('dashboard'))->with('success', 'Materi berhasil diunggah!');
        }

        // 4. JIKA GAGAL, TAMPILKAN PESAN ERROR ASLINYA
        return redirect()->to(base_url('dashboard'))->with('error', 'Gagal: ' . $file->getErrorString());
    }

    /**
     * KHUSUS ADMIN: Fungsi untuk menghapus materi
     */
    public function delete($id)
    {
        // PROTEKSI BERLAPIS
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to(base_url('dashboard'));
        }

        $model = new MateriModel();
        $materi = $model->find($id);

        if ($materi) {
            // Hapus file fisik dari folder public/uploads
            $filePath = ROOTPATH . 'public/uploads/' . $materi['nama_file'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
            
            // Hapus baris di database
            $model->delete($id);
        }

        return redirect()->to(base_url('dashboard'))->with('success', 'Materi berhasil dihapus.');
    }
}