<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// $routes->get('/', 'Home::index');
// Halaman Utama: Langsung diarahkan ke Login
$routes->get('/', 'Auth::login');

// Group Routes untuk Autentikasi
$routes->get('/login', 'Auth::login');
$routes->post('/auth/processLogin', 'Auth::processLogin');
$routes->get('/logout', 'Auth::logout');

// Group Routes untuk Dashboard (Materi)
$routes->get('/dashboard', 'Dashboard::index');
$routes->post('/dashboard/upload', 'Dashboard::upload');

// Route khusus untuk menangani delete (Hanya untuk Admin)
$routes->get('/dashboard/delete/(:num)', 'Dashboard::delete/$1');