<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modern Dashboard - E-Learning</title>
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700&family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --bg-body: #0b0e14;
            --sidebar-color: #11141d;
            --card-color: #1a1f2b;
            --accent-blue: #3b82f6;
            --accent-glow: rgba(59, 130, 246, 0.5);
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --border-color: rgba(255, 255, 255, 0.05);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'DM Sans', sans-serif;
            background-color: var(--bg-body);
            color: var(--text-main);
            display: flex;
            min-height: 100vh;
        }

        /* --- SIDEBAR --- */
        .sidebar {
            width: 260px;
            background-color: var(--sidebar-color);
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
        }

        .logo-section {
            padding: 30px 24px;
            font-family: 'Sora', sans-serif;
            font-weight: 700;
            font-size: 20px;
            color: var(--accent-blue);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .nav-menu { flex: 1; padding: 10px 16px; }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            color: var(--text-muted);
            text-decoration: none;
            border-radius: 12px;
            margin-bottom: 5px;
            transition: 0.3s;
            font-weight: 500;
        }

        .nav-item i { width: 24px; font-size: 18px; }
        .nav-item:hover, .nav-item.active {
            background: rgba(59, 130, 246, 0.1);
            color: var(--accent-blue);
        }

        /* --- MAIN CONTENT --- */
        .main-content {
            margin-left: 260px;
            flex: 1;
            padding: 30px;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }

        .welcome-text h1 { font-family: 'Sora', sans-serif; font-size: 24px; }
        .welcome-text p { color: var(--text-muted); font-size: 14px; }

        .user-profile {
            background: var(--card-color);
            padding: 8px 20px;
            border-radius: 100px;
            border: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* --- CARDS & TABLES --- */
        .grid-container {
            display: grid;
            grid-template-columns: <?= (session()->get('role') == 'admin') ? '350px 1fr' : '1fr' ?>;
            gap: 25px;
        }

        .glass-card {
            background: var(--card-color);
            border-radius: 20px;
            border: 1px solid var(--border-color);
            padding: 24px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .form-label { color: var(--text-muted); font-size: 13px; font-weight: 600; margin-bottom: 8px; display: block; }
        
        .form-input {
            width: 100%;
            background: #0b0e14;
            border: 1px solid var(--border-color);
            padding: 12px;
            border-radius: 10px;
            color: white;
            margin-bottom: 20px;
            outline: none;
        }

        .form-input:focus { border-color: var(--accent-blue); }

        .btn-primary {
            background: var(--accent-blue);
            color: white;
            border: none;
            width: 100%;
            padding: 12px;
            border-radius: 10px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 4px 14px var(--accent-glow);
            transition: 0.3s;
        }

        .btn-primary:hover { transform: translateY(-2px); opacity: 0.9; }

        /* --- TABLE STYLE --- */
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { text-align: left; color: var(--text-muted); font-size: 12px; text-transform: uppercase; padding: 15px; border-bottom: 1px solid var(--border-color); }
        td { padding: 15px; border-bottom: 1px solid var(--border-color); font-size: 14px; }
        
        .badge {
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
        }
        .badge-video { background: rgba(59, 130, 246, 0.2); color: #60a5fa; }
        .badge-photo { background: rgba(245, 158, 11, 0.2); color: #fbbf24; }

        .btn-action {
            padding: 6px 12px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 12px;
            margin-right: 5px;
            transition: 0.2s;
        }
        .btn-view { background: rgba(255,255,255,0.05); color: white; }
        .btn-view:hover { background: rgba(255,255,255,0.1); }
        .btn-del { background: rgba(239, 68, 68, 0.1); color: #f87171; }
        .btn-del:hover { background: #ef4444; color: white; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="logo-section">
            <i class="fas fa-graduation-cap"></i>
            <span>EduNext</span>
        </div>
        
        <div class="nav-menu">
            <a href="<?= base_url('/dashboard') ?>" class="nav-item active">
                <i class="fas fa-columns"></i> &nbsp; Dashboard
            </a>
        </div>

        <div style="padding: 20px; border-top: 1px solid var(--border-color);">
            <a href="<?= base_url('/logout') ?>" class="nav-item" style="color: #f87171;">
                <i class="fas fa-sign-out-alt"></i> &nbsp; Logout
            </a>
        </div>
    </div>

    <div class="main-content">
        <header>
            <div class="welcome-text">
                <h1>Halo, <?= strtoupper(session()->get('role')) ?>!</h1>
                <p>Pantau kemajuan kursus dan materi hari ini.</p>
            </div>
            <div class="user-profile">
                <div style="width: 32px; height: 32px; background: var(--accent-blue); border-radius: 50%; display: grid; place-items: center; font-weight: bold;">
                    <?= substr(session()->get('role'), 0, 1) ?>
                </div>
                <span style="font-size: 14px; font-weight: 600;"><?= session()->get('role') ?></span>
            </div>
        </header>

        <div class="grid-container">
            <?php if(session()->get('role') == 'admin'): ?>
            <div class="glass-card">
                <h3 style="font-family: 'Sora'; font-size: 18px; margin-bottom: 20px;">Tambah Materi</h3>
                <form action="<?= base_url('/dashboard/upload') ?>" method="post" enctype="multipart/form-data">
                    <label class="form-label">Judul Materi</label>
                    <input type="text" name="judul" class="form-input" placeholder="Masukkan judul..." required>

                    <label class="form-label">Tipe Konten</label>
                    <select name="tipe_file" class="form-input">
                        <option value="video">🎬 Video Pembelajaran</option>
                        <option value="foto">🖼️ Materi Visual</option>
                        <option value="pdf">📄 Materi PDF</option>
                        <option value="doc">📄 Materi Word</option>
                        <option value="docx">📄 Materi Excel</option>
                        <option value="ppt">📄 Materi PowerPoint</option>
                    </select>

                    <label class="form-label">File Materi</label>
                    <input type="file" name="file_materi" class="form-input" required>

                    <button type="submit" class="btn-primary">Mulai Upload</button>
                </form>
            </div>
            <?php endif; ?>

            <div class="glass-card">
                <h3 style="font-family: 'Sora'; font-size: 18px; margin-bottom: 20px;">Daftar Materi Tersedia</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Nama Materi</th>
                            <th>Kategori</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($materi)): ?>
                            <tr><td colspan="3" style="text-align:center; color: var(--text-muted); padding: 40px;">Belum ada data materi yang diunggah.</td></tr>
                        <?php else: ?>
                            <?php foreach($materi as $m): ?>
                            <tr>
                                <td style="font-weight: 500;"><?= $m['judul'] ?></td>
                                <td>
                                    <?php if($m['tipe_file'] == 'video'): ?>
                                        <span class="badge badge-video">Video Pembelajaran</span>
                                    <?php elseif($m['tipe_file'] == 'foto'): ?>
                                        <span class="badge badge-photo">Materi Visual</span>
                                    <?php elseif(in_array($m['tipe_file'], ['pdf', 'doc', 'docx', 'ppt'])): ?>
                                        <span class="badge" style="background: rgba(16, 185, 129, 0.2); color: #10b981;">
                                            <?= strtoupper($m['tipe_file']) ?> Document
                                        </span>
                                    <?php else: ?>
                                        <span class="badge" style="background: rgba(156, 163, 175, 0.2); color: #9ca3af;">
                                            File
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?= base_url('uploads/'.$m['nama_file']) ?>" target="_blank" class="btn-action btn-view">
                                        <i class="fas fa-external-link-alt"></i> Buka
                                    </a>
                                    <?php if(session()->get('role') == 'admin'): ?>
                                        <a href="<?= base_url('dashboard/delete/' . $m['id']) ?>" 
                                           class="btn-action btn-del" 
                                           onclick="return confirm('Hapus materi ini?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>