<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - EduNext E-Learning</title>
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700&family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --bg-body: #0b0e14;
            --card-color: #1a1f2b;
            --accent-blue: #3b82f6;
            --accent-glow: rgba(59, 130, 246, 0.5);
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --border-color: rgba(255, 255, 255, 0.05);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'DM Sans', sans-serif;
            background-color: var(--bg-body);
            background-image: radial-gradient(circle at 10% 20%, rgba(59, 130, 246, 0.05) 0%, transparent 40%), 
                              radial-gradient(circle at 90% 80%, rgba(59, 130, 246, 0.05) 0%, transparent 40%);
            color: var(--text-main);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow: hidden;
        }

        .login-wrapper {
            width: 100%;
            max-width: 420px;
            padding: 20px;
        }

        .glass-card {
            background: var(--card-color);
            border-radius: 24px;
            border: 1px solid var(--border-color);
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
            text-align: center;
        }

        .logo-brand {
            font-family: 'Sora', sans-serif;
            font-weight: 700;
            font-size: 24px;
            color: var(--accent-blue);
            margin-bottom: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 12px;
        }

        .login-header h3 {
            font-family: 'Sora', sans-serif;
            font-size: 20px;
            margin-bottom: 8px;
        }

        .login-header p {
            color: var(--text-muted);
            font-size: 14px;
            margin-bottom: 30px;
        }

        /* --- FORM STYLE --- */
        .form-group {
            text-align: left;
            margin-bottom: 20px;
        }

        .form-label {
            color: var(--text-muted);
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 8px;
            display: block;
            margin-left: 4px;
        }

        .form-input {
            width: 100%;
            background: #0b0e14;
            border: 1px solid var(--border-color);
            padding: 14px 16px;
            border-radius: 12px;
            color: white;
            outline: none;
            transition: 0.3s;
            font-size: 15px;
        }

        .form-input:focus {
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
        }

        .btn-login {
            background: var(--accent-blue);
            color: white;
            border: none;
            width: 100%;
            padding: 14px;
            border-radius: 12px;
            font-weight: 700;
            font-family: 'Sora', sans-serif;
            cursor: pointer;
            box-shadow: 0 4px 14px var(--accent-glow);
            transition: 0.3s;
            margin-top: 10px;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            opacity: 0.9;
        }

        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            color: #f87171;
            padding: 12px;
            border-radius: 10px;
            font-size: 13px;
            margin-bottom: 20px;
            border: 1px solid rgba(239, 68, 68, 0.2);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .footer-text {
            margin-top: 25px;
            font-size: 13px;
            color: var(--text-muted);
        }

        .footer-text a {
            color: var(--accent-blue);
            text-decoration: none;
            font-weight: 600;
        }
    </style>
</head>
<body>

<div class="login-wrapper">
    <div class="glass-card">
        <div class="logo-brand">
            <i class="fas fa-graduation-cap"></i>
            <span>EduNext</span>
        </div>
        
        <div class="login-header">
            <h3>Selamat Datang Kembali</h3>
            <p>Silakan masuk untuk melanjutkan belajar.</p>
        </div>

        <?php if(session()->getFlashdata('error')): ?>
            <div class="alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif; ?>

        <form action="<?= base_url('/auth/processLogin') ?>" method="post">
            <div class="form-group">
                <label class="form-label">Alamat Email</label>
                <input type="email" name="email" class="form-input" placeholder="contoh@email.com" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">Kata Sandi</label>
                <input type="password" name="password" class="form-input" placeholder="••••••••" required>
            </div>

            <button type="submit" class="btn-login">Masuk Sekarang</button>
        </form>

        <div class="footer-text">
            Belum punya akun? <a href="#">Daftar Baru</a>
        </div>
    </div>
    
    <p style="text-align: center; color: var(--text-muted); font-size: 11px; margin-top: 30px; opacity: 0.5;">
        &copy; 2026 EduNext Platform. All rights reserved.
    </p>
</div>

</body>
</html>