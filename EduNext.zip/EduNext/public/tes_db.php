<?php
$conn = mysqli_connect('127.0.0.1', 'root', '', 'kursus_online_db');

if (!$conn) {
    die('Error koneksi: ' . mysqli_connect_error());
}
echo 'BINGO! 🎉 Sah, database nyambung!';
?>